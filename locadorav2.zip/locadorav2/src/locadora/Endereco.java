package locadora;

public class Endereco {

    private String logradouro;
    private String numero;
    private String bairro;
    private String cep;
    private String complemento;

    public Endereco(
        String logradouro,
        String numero,
        String bairro,
        String cep,
        String complemento
    ) {
        super();
        this.logradouro = logradouro;
        this.numero = numero;
        this.bairro = bairro;
        this.cep = cep;
        this.complemento = complemento;
    }

    @Override
    public String toString() {
        return "Logradouro: " + logradouro + "\nNumero: " + numero + "\nBairro: " + bairro
            + "\nCEP: " + cep + "\nComplemento: " + complemento;
    }
}
