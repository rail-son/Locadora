package locadora;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class MenuImp implements Menu {

    private int range;
    private int opcao;
    private LocadoraServico locadora;

    public MenuImp() {
        this.range = 100000;
        this.opcao = 0;
        locadora = new Locadora();
    }

    @Override
    public void startMenu() {
        do {
            initializeData();
            decisorMenu();

            Scanner scanner = new Scanner(System.in);
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    cadastrarFilme(scanner);
                    break;
                case 2:
                    cadastrarSerie(scanner);
                    break;
                case 3:
                    cadastrarCliente(scanner);
                    break;
                case 4:
                    alugarProduto(scanner);
                    break;
                case 5:
                    consultarProdutos(scanner);
                    break;
                case 6:
                    consultarCliente(scanner);
                    break;
                case 7:
                    verificarAluguel(scanner);
                    break;
                case 8:
                    verificarProdutosMesmoTitulo(scanner);
                    break;
            }
        } while (opcao != 0);
    }

    private void decisorMenu() {
        System.out.println("1 - Cadastrar Filme");
        System.out.println("2 - Cadastrar S�rie");
        System.out.println("3 - Cadastrar Cliente");
        System.out.println("4 - Alugar Produto");
        System.out.println("5 - Consultar Produtos");
        System.out.println("6 - Consultar Cliente");
        System.out.println("7 - Verificar se est� alugado");
        System.out.println("8 - Verificar produtos com mesmo titulo");
        System.out.println("0 - Sair");
    }

    private void initializeData() {
        Cliente cliente1 = new Cliente("Maria Silva", "12345678901",
            new Endereco("Rua A", "123", "Centro", "12345-678", "Apartamento 101"));
        Cliente cliente2 = new Cliente("Jo�o Santos", "98765432101",
            new Endereco("Rua B", "456", "Bairro X", "54321-987", "Casa 202"));
        Cliente cliente3 = new Cliente("Ana Oliveira", "98712365401",
            new Endereco("Rua C", "789", "Bairro Y", "98765-432", "Sobrado 303"));
        locadora.cadastrarCliente(cliente1);
        locadora.cadastrarCliente(cliente2);
        locadora.cadastrarCliente(cliente3);

        Filme filme1 = new Filme("Titanic", 120, List.of("Drama", "Romance"), "DVD", 1, 101);
        Filme filme2 = new Filme("Matrix", 150, List.of("A��o", "Fic��o Cient�fica"), "DVD", 2,
            102);
        Filme filme3 = new Filme("Matrix", 150, List.of("A��o", "Fic��o Cient�fica"), "DVD", 2,
            121);
        locadora.cadastrarMidia(filme1);
        locadora.cadastrarMidia(filme2);

        Serie serie1 = new Serie("Friends", 30, List.of("Com�dia", "Drama"), "CASSETE", 1, 201,
            List.of(101, 102));
        Serie serie2 = new Serie("Breaking Bad", 45, List.of("Drama", "Crime"), "CASSETE", 2, 202,
            List.of(103, 104));
        locadora.cadastrarMidia(serie1);
        locadora.cadastrarMidia(serie2);
        locadora.cadastrarMidia(filme3);


    }

    private void cadastrarFilme(Scanner scanner) {
        System.out.println("Digite o titulo do filme: ");
        String tituloFilme = scanner.next();

        System.out.println("Digite o tempo de fita do Filme(minutos): ");
        int tempoDeFita = scanner.nextInt();

        List<String> generofilme = new ArrayList<>();
        String g_filme;
        do {
            System.out.println("Digite os g�neros do Filme (pelo menos 1, 0 para sair)");
            g_filme = scanner.next();
            if (!g_filme.equals("0")) {
                generofilme.add(g_filme);
            } else {
                if (generofilme.isEmpty()) {
                    System.out.println("Pelo menos um g�nero deve ser inserido");
                }
            }
        } while (!g_filme.equals("0")
            || generofilme.isEmpty()); // enquanto n�o for digitado 0 ou a lista estiver vazia

        System.out.println("Digite o tipo(CASSETE/DVD): ");
        String tipo = scanner.next();

        System.out.println("Digite o setor: ");
        int setor = scanner.nextInt();

        System.out.println("Digite a quantidade do exemplar: ");
        int qtd = scanner.nextInt();

        for (int i = 0; i < qtd; i++) {
            Filme filme = new Filme(tituloFilme, tempoDeFita, generofilme, tipo, setor,
                (int) (Math.random() * range) + 1);
            locadora.cadastrarMidia(filme);
        }
    }

    private void cadastrarSerie(Scanner scanner) {
        System.out.println("Digite o titulo do s�rie: ");
        String tituloSerie = scanner.next();

        System.out.println("Digite o tempo de fita do s�rie: ");
        int tempoDeFitaSerie = scanner.nextInt();

        List<String> genero = new ArrayList<>();
        String g;
        do {
            System.out.println("Digite os g�neros da s�rie (pelo menos 1, 0 para sair)");
            g = scanner.next();
            if (!g.equals("0")) {
                genero.add(g);
            } else {
                if (genero.isEmpty()) {
                    System.out.println(
                        "Pelo menos um g�nero deve ser inserido"); // isEmpty para verificar se a lista ta vazia
                }
            }
        } while (!g.equals("0")
            || genero.isEmpty()); // enquanto n�o for digitado 0 ou a lista estiver vazia

        System.out.println("Digite o tipo(CASSETE/DVD): ");
        String tipoSerie = scanner.next();

        System.out.println("Digite o setor: ");
        int setorSerie = scanner.nextInt();

        System.out.println(
            "Digite a quantidade do exemplar: "); // enquanto n�o for digitado 0 ou a lista estiver vazia
        int qtdSerie = scanner.nextInt();

        System.out.println("Quantidade de epis�dios:");
        int qtdEpisodios = scanner.nextInt();

        for (int i = 0; i < qtdSerie; i++) {
            List<Integer> codFilmes = new ArrayList<>();
            for (int j = 0; j < qtdEpisodios; j++) {
                codFilmes.add((int) (Math.random() * range) + 1);
            }
            Serie serie = new Serie(tituloSerie, tempoDeFitaSerie, genero, tipoSerie, setorSerie,
                (int) (Math.random() * range) + 1, codFilmes);
            locadora.cadastrarMidia(serie);
        }
    }

    private void cadastrarCliente(Scanner scanner) {
        System.out.println("Digite o nome do cliente");
        String nomeCliente = scanner.next();

        System.out.println("Digite o cpf do cliente");
        String cpfCliente = scanner.next();

        System.out.println("Digite o logradouro do cliente");
        String logradouroCliente = scanner.next();

        System.out.println("Digite o n�mero do cliente");
        String numeroCliente = scanner.next();

        System.out.println("Digite o bairro do cliente");
        String bairroCliente = scanner.next();

        System.out.println("Digite o cep do cliente");
        String cepCliente = scanner.next();

        System.out.println("Digite o complemento do cliente");
        String complementoCliente = scanner.next();

        Endereco endereco = new Endereco(logradouroCliente, numeroCliente, bairroCliente,
            cepCliente, complementoCliente);
        Cliente cliente = new Cliente(nomeCliente, cpfCliente, endereco);
        locadora.cadastrarCliente(cliente);
    }

    private void alugarProduto(Scanner scanner) {
        //Imprimir clientes
        System.out.println("Clientes cadastrados:");
        for (Cliente c : locadora.listarClientes()) {
            System.out.println(c.getNome());
            System.out.println(c.getCpf());
            System.out.println();
        }

        //Imprimir midias
        System.out.println("Midias cadastradas:");
        for (Midia m : locadora.listarMidias()) {
            System.out.println(m.getTitulo() + " - " + m.getCodProd());
            if (m instanceof Filme) {
                System.out.println("Tipo: Filme");
            } else {
                System.out.println("Tipo: S�rie");
            }
            System.out.println();
        }

        System.out.println();

        String cpfLocacao = scanner.nextLine();
        Cliente clienteLocacao = null;

        boolean cancelarLocacao = false;

        do { // verificar se CPF existe no cadastro dos clientes
            System.out.println("Digite o CPF do cliente (0 para cancelar):");
            cpfLocacao = scanner.nextLine();

            if (cpfLocacao.equals("0")) {
                System.out.println("Loca��o cancelada.");
                cancelarLocacao = true;
                break; // Sai do loop do-while
            }

            clienteLocacao = locadora.getClienteByCpf(cpfLocacao);

            if (clienteLocacao == null) {
                System.out.println(
                    "CPF n�o encontrado. Por favor, digite um CPF v�lido ou 0 para cancelar.");
            }
        } while (clienteLocacao == null);

        if (cancelarLocacao) {
            return;
        }
        LocacaoServico locacao = new Locacao(clienteLocacao);

        //For para usuario escrever quais midias quer e adicionar na locacao
        while (true) {
            System.out.println("Digite o c�digo da m�dia que deseja alugar:");
            // String tituloMidia = scanner.nextLine();
            int codProd = scanner.nextInt();
            Midia midiaLocacao = locadora.getMidiaByCod(codProd);

            if (midiaLocacao != null) {
                locacao.adicionaMidia(midiaLocacao);
            } else {
                System.out.println("M�dia com c�digo '" + codProd
                    + "' n�o encontrada. Por favor, digite um t�tulo v�lido.");
                continue; // Pula para a pr�xima itera��o do loop
            }

            scanner.nextLine();

            System.out.println("Deseja alugar mais alguma m�dia? (s/n)");
            String continuar = scanner.nextLine();
            if (continuar.equals("n")) {
                break;
            }
        }

        System.out.println("Digite o tempo de loca��o(dias): ");
        int tempoLocacao = scanner.nextInt();
        Locacao locado = locacao.locarMidia(tempoLocacao);

        locadora.cadastrarLocacao(locado);
        System.out.println("Valor: " + locado.getValor()); // exibe valor da loca��o
    }

    private void consultarProdutos(Scanner scanner) {
        System.out.println("Consultar Produto pelo Código:");
        Midia midia = locadora.getMidiaByCod(scanner.nextInt());

        if (midia != null) {
            System.out.println("Produto encontrado");
            System.out.println("Título: " + midia.getTitulo());
            System.out.println("Tipo: " + midia.getTipo());
            System.out.println("Gênero: " + midia.getGenero());
            System.out.println("Setor: " + midia.getSetor());
            System.out.println("Código: " + midia.getCodProd());
            System.out.println();
        } else {
            System.out.println("Produto n�o encontrado.");
        }
    }

    private void consultarCliente(Scanner scanner) {
        System.out.println("Consultar Cliente por CPF:");
        System.out.println("Digite o CPF do cliente (0 para sair):");
        String cpfConsulta;
        do {
            cpfConsulta = scanner.next();
            if (!cpfConsulta.equals("0")) {
                Cliente clienteConsultado = locadora.getClienteByCpf(cpfConsulta);
                if (clienteConsultado != null) {
                    System.out.println("\nCliente encontrado:");
                    System.out.println("Nome: " + clienteConsultado.getNome());
                    System.out.println("CPF: " + clienteConsultado.getCpf());
                    System.out.println("Endere�o: " + clienteConsultado.getEndereco() + "\n");
                    break;
                } else {
                    System.out.println(
                        "Cliente com CPF '" + cpfConsulta + "' n�o encontrado.");
                }
                System.out.println("Digite outro CPF (0 para sair):");
            }
        } while (!cpfConsulta.equals("0"));
    }

    private void verificarAluguel(Scanner scanner) {
        scanner.nextLine();
        System.out.println("Verificar se est� alugado:");
        List<Midia> midias = locadora.getMidiaByTitulo(scanner.nextLine());

        if (!midias.isEmpty()) {
            for (Midia singleMidia : midias) {
                if (singleMidia.isAlugado()) {
                    for (Locacao locacao1 : locadora.listarLocacoes()) {
                        if (locacao1.getMidias().contains(singleMidia)) {
                            System.out.println("Produto Alugado:");
                            System.out.println(("Codigo produto: " + singleMidia.getCodProd()));
                            System.out.println("Titulo: " + singleMidia.getTitulo());
                            System.out.println("Alugado por: " + locacao1.getCliente().getNome());
                            System.out.println("Data devolução: " + locacao1.getDataLocacao()
                                .plusDays(locacao1.getTempoLocacao()));
                        }
                    }
                } else {
                    System.out.println("Produto Disponivel:");
                    System.out.println(("Codigo produto: " + singleMidia.getCodProd()));
                    System.out.println("Titulo: " + singleMidia.getTitulo());
                }
                System.out.println();
            }
        } else {
            System.out.println("Produto n�o encontrado.");
        }
    }

    private void verificarProdutosMesmoTitulo(Scanner scanner) {
        scanner.nextLine();
        System.out.println("Verificar produtos com mesmo titulo:");
        Map<Midia, Integer> teste = locadora.getQtdMidia();

        for (Map.Entry<Midia, Integer> entry : teste.entrySet()) {
            System.out.println(entry.getKey().getTitulo() + " - " + entry.getValue());
        }
    }
}
