package locadora;

import java.util.List;

public class Serie extends Midia {

    private List<Integer> codFilmes;

    public Serie(
        String titulo,
        int tempoDeFita,
        List<String> genero,
        String tipo,
        int setor,
        int codProd,
        List<Integer> codFilmes
    ) {
        super(titulo, tempoDeFita, genero, tipo, setor, codProd);
        this.codFilmes = codFilmes;
    }
}
