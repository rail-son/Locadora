package locadora;

public interface Menu {

    void startMenu();
}
