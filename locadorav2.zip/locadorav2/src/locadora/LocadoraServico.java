package locadora;

import java.util.List;
import java.util.Map;

public interface LocadoraServico {

    void cadastrarCliente(Cliente cliente);

    void cadastrarMidia(Midia midia);

    void cadastrarLocacao(Locacao locacao);

    List<Cliente> listarClientes();

    List<Midia> listarMidias();

    List<Locacao> listarLocacoes();

    Cliente getClienteByCpf(String cpf);

    List<Midia> getMidiaByTitulo(String titulo);

    Midia getMidiaByCod(int codProd);

    Map<Midia, Integer> getQtdMidia();
}
