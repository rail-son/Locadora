package locadora;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Locadora implements LocadoraServico {

    List<Cliente> clientes = new ArrayList<>();
    List<Locacao> locacoes = new ArrayList<>();
    List<Midia> midias = new ArrayList<>();


    @Override
    public void cadastrarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    @Override
    public void cadastrarMidia(Midia midia) {
        midias.add(midia);
    }

    @Override
    public void cadastrarLocacao(Locacao locacao) {
        locacoes.add(locacao);
    }

    @Override
    public List<Cliente> listarClientes() {
        return clientes;
    }

    @Override
    public List<Midia> listarMidias() {
        return midias;
    }

    @Override
    public List<Locacao> listarLocacoes() {
        return locacoes;
    }

    @Override
    public Cliente getClienteByCpf(String cpf) {
        for (Cliente cliente : clientes) {
            if (cliente.getCpf().equals(cpf)) {
                return cliente;
            }
        }
        return null;
    }

    @Override
    public List<Midia> getMidiaByTitulo(String titulo) {
        List<Midia> midiasByTitulo = new ArrayList<>();

        for (Midia midia : midias) {
            if (midia.getTitulo().toLowerCase().contains(titulo.toLowerCase())) {
                midiasByTitulo.add(midia);
            }
        }

        return midiasByTitulo;
    }

    @Override
    public Midia getMidiaByCod(int codProd) {
        for (Midia midia : midias) {
            if (midia.getCodProd() == (codProd)) {
                return midia;
            }
        }
        return null;
    }

    @Override
    public Map<Midia, Integer> getQtdMidia() {
        Map<Midia, Integer> qtdMidia = new HashMap<>();
        for (Midia midia : midias) {
            if (qtdMidia.containsKey(midia)) {
                qtdMidia.put(midia, qtdMidia.get(midia) + 1);
            } else {
                qtdMidia.put(midia, 1);
            }
        }
        return qtdMidia;
    }
}
