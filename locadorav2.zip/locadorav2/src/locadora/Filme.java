package locadora;

import java.util.List;

public class Filme extends Midia {

    public Filme(
        String titulo,
        int tempoDeFita,
        List<String> genero,
        String tipo,
        int setor,
        int codProd
    ) {
        super(titulo, tempoDeFita, genero, tipo, setor, codProd);

    }
}
