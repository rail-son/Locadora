package locadora;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;


public class Locacao implements LocacaoServico {

    private Cliente cliente;
    private Set<Midia> midias;
    private Double valor;
    private int tempoLocacao;
    private LocalDate dataLocacao;

    public Locacao(Cliente cliente) {
        this.cliente = cliente;
        this.midias = new HashSet<>();
        this.valor = 0.0;
        this.tempoLocacao = 0;
        this.dataLocacao = LocalDate.now();
    }

    public Cliente getCliente() {
        return cliente;
    }

    public Set<Midia> getMidias() {
        return midias;
    }

    public Double getValor() {
        return valor;
    }

    public int getTempoLocacao() {
        return tempoLocacao;
    }

    public LocalDate getDataLocacao() {
        return dataLocacao;
    }

    @Override
    public void adicionaMidia(Midia midia) {
        if (!midias.contains(midia) && !midia.isAlugado()) {
            midias.add(midia);
            midia.setAlugado(true);
        } else {
            System.out.println("locadora.Midia já adicionada ou já alugada");
        }

    }

    @Override
    public Locacao locarMidia(int quantidadeDias) {
        tempoLocacao = quantidadeDias;
        for (Midia midia : midias) {
            valor += 5; // 5 reais por m�dia
        }
        valor = valor + (0.40 * quantidadeDias); // 40 cents por dia
        return this;
    }

    @Override
    public Locacao getLocacao() {
        return this;
    }
}
