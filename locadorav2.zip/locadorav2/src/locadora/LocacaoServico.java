package locadora;

public interface LocacaoServico {

    void adicionaMidia(Midia midia);

    Locacao locarMidia(int quantidadeDias);

    Locacao getLocacao();
}
