package locadora;

import java.util.List;

public abstract class Midia {

    private String titulo;
    private int tempoDeFita;
    private List<String> genero;
    private String tipo; // CASSETE OU DVD
    private int setor;
    private boolean alugado;
    private int codProd;


    public Midia(
        String titulo, int tempoDeFita, List<String> genero, String tipo, int setor, int codProd
    ) {
        this.titulo = titulo;
        this.tempoDeFita = tempoDeFita;
        this.genero = genero;
        this.tipo = tipo;
        this.setor = setor;
        this.alugado = false;
        this.codProd = codProd;
    }

    public void setAlugado(boolean alugado) {
        this.alugado = alugado;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getTempoDeFita() {
        return tempoDeFita;
    }

    public List<String> getGenero() {
        return genero;
    }

    public String getTipo() {
        return tipo;
    }

    public int getSetor() {
        return setor;
    }

    public boolean isAlugado() {
        return alugado;
    }

    public int getCodProd() {
        return codProd;
    }

    //Override equals e hash para o nome em lower case
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Midia) {
            Midia midia = (Midia) obj;
            return midia.getTitulo().toLowerCase().equals(this.getTitulo().toLowerCase());
        }
        return false;
    }

    @Override
    public int hashCode() {
        return this.getTitulo().toLowerCase().hashCode();
    }
}
