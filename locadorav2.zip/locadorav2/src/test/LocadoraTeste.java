package test;

import static org.junit.Assert.assertEquals;

import java.util.List;
import locadora.Cliente;
import locadora.Endereco;
import locadora.Filme;
import locadora.Locacao;
import locadora.Locadora;
import locadora.LocadoraServico;
import locadora.Serie;
import org.junit.Before;
import org.junit.Test;

public class LocadoraTeste {

    private LocadoraServico locadora;

    @Before
    public void setUp() {
        locadora = new Locadora();
    }

    @Test
    public void testCadastrarCliente() {
        Cliente cliente1 = new Cliente("Maria Silva", "12345678901",
            new Endereco("Rua A", "123", "Centro", "12345-678", "Apartamento 101"));

        locadora.cadastrarCliente(cliente1);

        assertEquals(1, locadora.listarClientes().size());
    }

    @Test
    public void testCadastrarMidia() {
        Filme filme1 = new Filme("Titanic", 120, List.of("Drama", "Romance"), "DVD", 1, 101);
        Serie serie1 = new Serie("Friends", 30, List.of("Com�dia", "Drama"), "CASSETE", 1, 201,
            List.of(101, 102));

        locadora.cadastrarMidia(filme1);
        locadora.cadastrarMidia(serie1);

        assertEquals(2, locadora.listarMidias().size());
    }

    @Test
    public void testCadastrarLocacao() {
        Cliente cliente1 = new Cliente("Maria Silva", "12345678901",
            new Endereco("Rua A", "123", "Centro", "12345-678", "Apartamento 101"));
        Filme filme1 = new Filme("Titanic", 120, List.of("Drama", "Romance"), "DVD", 1, 101);
        Serie serie1 = new Serie("Friends", 30, List.of("Com�dia", "Drama"), "CASSETE", 1, 201,
            List.of(101, 102));

        locadora.cadastrarCliente(cliente1);
        locadora.cadastrarMidia(filme1);
        locadora.cadastrarMidia(serie1);

        Locacao locacao = new Locacao(cliente1);
        locacao.adicionaMidia(filme1);
        locacao.adicionaMidia(serie1);

        locadora.cadastrarLocacao(locacao);

        assertEquals(1, locadora.listarLocacoes().size());
    }

    @Test
    public void testGetClienteByCpf() {
        Cliente cliente1 = new Cliente("Maria Silva", "12345678901",
            new Endereco("Rua A", "123", "Centro", "12345-678", "Apartamento 101"));
        Cliente cliente2 = new Cliente("Joao Silva", "12345678902",
            new Endereco("Rua B", "123", "Centro", "12345-678", "Apartamento 102"));

        locadora.cadastrarCliente(cliente1);
        locadora.cadastrarCliente(cliente2);

        assertEquals(cliente1, locadora.getClienteByCpf("12345678901"));
    }

    @Test
    public void testGetMidiaByTitulo() {
        Filme filme1 = new Filme("Titanic", 120, List.of("Drama", "Romance"), "DVD", 1, 101);
        Filme filme2 = new Filme("Titanic 2", 120, List.of("Drama", "Romance"), "DVD", 1, 102);
        Serie serie1 = new Serie("Friends", 30, List.of("Com�dia", "Drama"), "CASSETE", 1, 201,
            List.of(101, 102));

        locadora.cadastrarMidia(filme1);
        locadora.cadastrarMidia(filme2);
        locadora.cadastrarMidia(serie1);

        assertEquals(2, locadora.getMidiaByTitulo("Titanic").size());
    }

    @Test
    public void testGetMidiaByCod() {
        Filme filme1 = new Filme("Titanic", 120, List.of("Drama", "Romance"), "DVD", 1, 101);
        Filme filme2 = new Filme("Titanic 2", 120, List.of("Drama", "Romance"), "DVD", 1, 102);
        Serie serie1 = new Serie("Friends", 30, List.of("Com�dia", "Drama"), "CASSETE", 1, 201,
            List.of(101, 102));

        locadora.cadastrarMidia(filme1);
        locadora.cadastrarMidia(filme2);
        locadora.cadastrarMidia(serie1);

        assertEquals(filme1, locadora.getMidiaByCod(101));
    }

    @Test
    public void testGetQtdMidia() {
        Filme filme1 = new Filme("Titanic", 120, List.of("Drama", "Romance"), "DVD", 1, 101);
        Filme filme2 = new Filme("Titanic 2", 120, List.of("Drama", "Romance"), "DVD", 1, 102);
        Serie serie1 = new Serie("Friends", 30, List.of("Com�dia", "Drama"), "CASSETE", 1, 201,
            List.of(101, 102));

        locadora.cadastrarMidia(filme1);
        locadora.cadastrarMidia(filme2);
        locadora.cadastrarMidia(serie1);

        assertEquals(3, locadora.getQtdMidia().size());
    }

    @Test
    public void testListarClientes() {
        Cliente cliente1 = new Cliente("Maria Silva", "12345678901",
            new Endereco("Rua A", "123", "Centro", "12345-678", "Apartamento 101"));
        Cliente cliente2 = new Cliente("Joao Silva", "12345678902",
            new Endereco("Rua B", "123", "Centro", "12345-678", "Apartamento 102"));

        locadora.cadastrarCliente(cliente1);
        locadora.cadastrarCliente(cliente2);

        assertEquals(2, locadora.listarClientes().size());
    }

    @Test
    public void testListarMidias() {
        Filme filme1 = new Filme("Titanic", 120, List.of("Drama", "Romance"), "DVD", 1, 101);
        Filme filme2 = new Filme("Titanic 2", 120, List.of("Drama", "Romance"), "DVD", 1, 102);
        Serie serie1 = new Serie("Friends", 30, List.of("Com�dia", "Drama"), "CASSETE", 1, 201,
            List.of(101, 102));

        locadora.cadastrarMidia(filme1);
        locadora.cadastrarMidia(filme2);
        locadora.cadastrarMidia(serie1);

        assertEquals(3, locadora.listarMidias().size());
    }

    @Test
    public void testListarLocacoes() {
        Cliente cliente1 = new Cliente("Maria Silva", "12345678901",
            new Endereco("Rua A", "123", "Centro", "12345-678", "Apartamento 101"));
        Filme filme1 = new Filme("Titanic", 120, List.of("Drama", "Romance"), "DVD", 1, 101);
        Serie serie1 = new Serie("Friends", 30, List.of("Com�dia", "Drama"), "CASSETE", 1, 201,
            List.of(101, 102));

        locadora.cadastrarCliente(cliente1);
        locadora.cadastrarMidia(filme1);
        locadora.cadastrarMidia(serie1);

        Locacao locacao = new Locacao(cliente1);
        locacao.adicionaMidia(filme1);
        locacao.adicionaMidia(serie1);

        locadora.cadastrarLocacao(locacao);

        assertEquals(1, locadora.listarLocacoes().size());
    }

}
