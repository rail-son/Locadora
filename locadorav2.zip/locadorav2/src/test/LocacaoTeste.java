package test;

import static org.junit.Assert.assertEquals;

import java.util.List;
import locadora.Cliente;
import locadora.Endereco;
import locadora.Filme;
import locadora.Locacao;
import locadora.LocacaoServico;
import locadora.LocadoraServico;
import locadora.Locadora;
import locadora.Serie;
import org.junit.Before;
import org.junit.Test;

public class LocacaoTeste {
    private LocacaoServico locacao;

    @Before
    public void setUp() {
        Cliente cliente1 = new Cliente("Maria Silva", "12345678901",
            new Endereco("Rua A", "123", "Centro", "12345-678", "Apartamento 101"));
        locacao = new Locacao(cliente1);
    }

    @Test
    public void testAdicionaMidia() {
        Filme filme1 = new Filme("Titanic", 120, List.of("Drama", "Romance"), "DVD", 1, 101);
        Serie serie1 = new Serie("Friends", 30, List.of("Com�dia", "Drama"), "CASSETE", 1, 201,
            List.of(101, 102));

        locacao.adicionaMidia(filme1);
        locacao.adicionaMidia(serie1);

        assertEquals(2, locacao.getLocacao().getMidias().size());
    }

    @Test
    public void testLocarMidia() {
        Filme filme1 = new Filme("Titanic", 120, List.of("Drama", "Romance"), "DVD", 1, 101);
        Serie serie1 = new Serie("Friends", 30, List.of("Com�dia", "Drama"), "CASSETE", 1, 201,
            List.of(101, 102));

        locacao.adicionaMidia(filme1);
        locacao.adicionaMidia(serie1);

        locacao.locarMidia(3);

        assertEquals(3, locacao.getLocacao().getTempoLocacao());
        assertEquals(2, locacao.getLocacao().getMidias().size());
    }
}
